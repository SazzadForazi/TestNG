public class Test {
    public static void main(String[] args) {
        int id= (int)(Math.random()*(1000-1)+1);
        System.out.println(id);
    }
}
